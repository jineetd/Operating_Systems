#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<stdlib.h>
#include<fcntl.h> 
#include<string.h>
int shmid,shmid1;
int *flag;
char *final_path;
char *filename;
int search(char *path)
{
	//printf("Search called in %s\n",path);
	chdir(path);
	char curr_path[256];
	getcwd(curr_path,256);
	printf("current path=%s\n",curr_path);
	flag=shmat(shmid,NULL,0);
	final_path=shmat(shmid1,NULL,0);
	int k=0;
	int pid,pid1;
	pid=fork();
	if(pid==0)
	{
		flag=shmat(shmid,NULL,0);
		final_path=shmat(shmid1,NULL,0);
		int fd=creat("file.txt",0777);
		dup2(fd,1);
		char *arg[]={"ls","-l",0};
		k=1;
		execv("/bin/ls",arg);
	}
	else if((pid1=fork())==0 && k==0)
	{
		flag=shmat(shmid,NULL,0);
		final_path=shmat(shmid1,NULL,0);
		int status;
		waitpid(pid,&status,0);
		int fd=open("file.txt",O_RDONLY);
		dup2(fd,0);
		//printf("file descriptor:%d\n",fd);
		char *arg[]={"grep",filename,0};

		int op=creat("result.txt",0777);
		dup2(op,1);
		execv("/bin/grep",arg);
	}
	else
	{
		int status;
		waitpid(pid1,&status,0);	
		char c[300];
		FILE *ptr;
		ptr=fopen("result.txt","r");

		while(1)
		{
			printf("Hi\n");
			int isEnd=fscanf(ptr,"%[^\n]",c);
			if(c[0]=='-')
			{
				int count=0;
				int i;
				for(i=0;i<300;i++)
				{
					if(c[i]==' ')
						count++;
					if(count==8)
						break;
				}
				i++;
				char *file_name;
				strcpy(file_name,c+i);
				printf("file=%s\n",file_name);
				if((*flag)!=1)
				{
					if(strcmp(filename,file_name)==0)
					{
						printf("File found....\n");
						*flag=1;
						final_path=path;
						exit(1);
					}
				}
			}
			else if(isEnd==EOF)
				break;
		}
	}
	return 0;
}
int main(int c,char *argv[])
{
	filename=argv[1];

	int id=atoi(argv[2]);
	int marks=atoi(argv[3]);
	
	/*shared memory for flag*/
	shmid=shmget(IPC_PRIVATE,sizeof(int),0777|IPC_CREAT);
	flag=(int *)shmat(shmid,NULL,0);

	shmid1=shmget(IPC_PRIVATE,256*sizeof(int),0777|IPC_CREAT);
	final_path=(char *)shmat(shmid1,NULL,0);

	char path[]="/home/jineet/Operating_Systems/Assignment2/user/Evaluator/";

	search(path);
	int pid2;
	while((*flag)==0)
	{
		//kill(-1,SIGSTOP);
		
		flag=shmat(shmid,NULL,0);
		final_path=shmat(shmid1,NULL,0);
		//search(path);
		chdir(path);
		printf("pid=%d ppid:%d path=%s\n",getpid(),getppid(),path);
		if((*flag)==0)
		{
			int pid,pid1;
			int k=0;
			pid=fork();
			if(pid==0)
			{
				flag=shmat(shmid,NULL,0);
				final_path=shmat(shmid1,NULL,0);
				int fd=creat("file1.txt",0777);
				dup2(fd,1);
				char *arg[]={"ls","-F",0};
				k=1;
				execv("/bin/ls",arg);
			}
			else if((pid1=fork())==0 && k==0)
			{
				flag=shmat(shmid,NULL,0);
				final_path=shmat(shmid1,NULL,0);
				int status;
				waitpid(pid,&status,0);
				int fd=open("file1.txt",O_RDONLY);
				dup2(fd,0);
				//printf("file descriptor:%d\n",fd);
				char *arg[]={"grep","/",0};

				int op=creat("result1.txt",0777);
				dup2(op,1);
				execv("/bin/grep",arg);
			}
			else
			{
				int status;
				waitpid(pid1,&status,0);
				char c[300];
				FILE *ptr;
				ptr=fopen("result1.txt","r");
				//fscanf(ptr,"%[^\n]",c);
				int cnt=0;
				while(1)
				{
					//printf("stuck\n");
					int isEnd= fscanf(ptr,"%[^\n]",c);
					if(isEnd==EOF)
						break;
					else
						cnt++;
					
					
					if(*(flag)==0)
					{
						
						pid2=fork();
						if(pid2==0){
							
							kill(getpid(),SIGSTOP);
							flag=shmat(shmid,NULL,0);
							final_path=shmat(shmid1,NULL,0);
							strcat(path,c);
							search(path);
							break;
						}
						else 
							waitpid(pid2,NULL,WUNTRACED);
					}
				}
				fclose(ptr);
				if(cnt==0)
					break;


			}
		}
	}
	kill(pid2,SIGCONT);
	printf("Final path:%s\n",final_path);
	return 0;

}