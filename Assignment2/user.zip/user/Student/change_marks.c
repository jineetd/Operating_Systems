#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<stdlib.h>
#include<fcntl.h> 
#include<string.h>
int shmid,shmid1;
int main(int c ,char *argv[])
{
	char *filename=argv[1];

	int id=atoi(argv[2]);
	int marks=atoi(argv[3]);
	
	/*shared memory for flag*/
	shmid=shmget(IPC_PRIVATE,sizeof(int),0777|IPC_CREAT);
	int *flag=shmat(shmid,NULL,0);

	/*shared memory for current_path*/
	shmid1=shmget(IPC_PRIVATE,256*sizeof(char),0777|IPC_CREAT);
	char *current_path=shmat(shmid1,NULL,0);

	getcwd(current_path,256);

	/*Going to evaluator directory*/
	
	int a=chdir("../Evaluator");
	printf("status: %d\n",a);
	*flag=0;
	getcwd(current_path,256);
	printf("cwd:%s\n",current_path);

	//const char *ps_envp[] ={"PATH=/bin:/usr/bin","TERM=console",0};

	int dir_exists=1;
	/*forking the child process*/
	
	
	int k=0;
	int pid;
	pid=fork();
	if(pid==0)
	{
	flag=shmat(shmid,NULL,0);
	int fd=creat("file.txt",0777);
	dup2(fd,1);
	char *arg[]={"ls","-l",0};
	k=1;
	execv("/bin/ls",arg);

	}
	else if(fork()==0 && k==0)
	{
	flag=shmat(shmid,NULL,0);
	int status;
	waitpid(pid,&status,0);
	int fd=open("file.txt",O_RDONLY);
	dup2(fd,0);
	//printf("file descriptor:%d\n",fd);
	char *arg[]={"grep",filename,0};

	int op=creat("result.txt",0777);
	dup2(op,1);
	execv("/bin/grep",arg);
	}
	else{
	char c[300];
	FILE *ptr;
	ptr=fopen("result.txt","r");
	//fscanf(ptr,"%[^\n]",c);
	dir_exists=0;

	while(1){
		fscanf(ptr,"%[^\n]",c);
		if(strcmp(c,"")==0){
			printf("File not found\n");
			break;
		}
		else if(c[0]=='d'){
			dir_exists=1;
			int count=0;
			int i;
			for(i=0;i<300;i++)
			{
				if(c[i]==' ')
					count++;
				if(count==8)
					break;
			}
			i++;
			char *dir_name;
			strcpy(dir_name,c+i);
			if((*flag)!=1)
			{
				char cwd[256];
				getcwd(cwd,256);
				strcat(cwd,"/");
				strcat(cwd,dir_name);
				chdir(cwd);
			}
			else
				exit(1);
		}
		else if(c[0]=='-')
		{
			int count=0;
			int i;
			for(i=0;i<300;i++)
			{
				if(c[i]==' ')
					count++;
				if(count==8)
					break;
			}
			i++;
			char *file_name;
			strcpy(file_name,c+i);
			if((*flag)!=1)
			{
				if(strcmp(filename,file_name)==0)
				{
					printf("File found....\n");
					*flag=1;
					exit(1);
				}
			}
		}
	}
	fclose(ptr);

	}


	return 0;
}